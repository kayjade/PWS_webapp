Please complete all your project development in this directory and
its subdirectories (which you may create as neeeded).

# Reference

+ Webpage Design

[alvarotrigo/fullPage.js](https://github.com/alvarotrigo/fullPage.js)

[Non-responsive Bootstrap](https://getbootstrap.com/docs/3.3/examples/non-responsive/)

[Change bootstrap navbar collapse breakpoint without using LESS](https://stackoverflow.com/questions/19827605/change-bootstrap-navbar-collapse-breakpoint-without-using-less)

[Hover effect](https://miketricking.github.io/bootstrap-image-hover/)

[Flush footer to the bottom of the page](https://chrisbracco.com/css-sticky-footer-effect/)

[jQuery-File-Upload](https://github.com/blueimp/jQuery-File-Upload)

[D3 Stream Graph](https://bl.ocks.org/mbostock/4060954)

[Save SVG as PNG](https://bl.ocks.org/mbostock/6466603)
