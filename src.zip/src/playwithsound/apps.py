from django.apps import AppConfig


class PlayWithSoundConfig(AppConfig):
    name = 'play_with_sound'
