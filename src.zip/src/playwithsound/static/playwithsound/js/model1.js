function drawpicture(recorder){
    var svg = d3.select("svg"),
        width = +svg.attr("width"),
        height = +svg.attr("height");
    mode1();
    function mode1() {
        var width = Math.max(960, innerWidth),
            height = Math.max(500, innerHeight);

        var x1 = width / 2,
            y1 = height / 2,
            x0 = x1,
            y0 = y1,
            i = 0,
            r = 200,
            τ = 2 * Math.PI;

        var context = svg.node().getContext("2d");
        context.globalCompositeOperation = "lighter";
        context.lineWidth = 2;

        d3.timer(function () {
            //context.clearRect(0, 0, width, height);

            var z = d3.hsl(++i % 360, 1, .5).rgb(),
                c = "rgba(" + z.r + "," + z.g + "," + z.b + ",",
                x = x0 += (x1 - x0) * .1,
                y = y0 += (y1 - y0) * .1;

            d3.select({}).transition()
                .duration(2000)
                .ease(Math.sqrt)
                .tween("circle", function () {
                    return function (t) {
                        context.strokeStyle = c + (1 - t) + ")";
                        context.beginPath();
                        context.arc(x, y, r * t, 0, τ);
                        context.stroke();
                    };
                });
        });

        function getdata() {
            TD = recorder.timeData;
            FD = recorder.freqData;

            r = Math.max(FD.max(), 200);
            x1 = Math.max(TD.avg(),width);
            y1 = Math.max(FD.avg(),height);
            d3.event.preventDefault();
        }
        svg.setInterval(getdata, 10000);
    }

    function mode2() {
        var n = 20, // number of layers
            m = 200, // number of samples per layer
            k = 10; // number of bumps per layer

        var stack = d3.stack()
                .keys(d3.range(n))
                .offset(d3.stackOffsetWiggle),
            layers0 = stack(d3.transpose(d3.range(n).map(function () {
                return bumps(m, k);
            }))),
            layers1 = stack(d3.transpose(d3.range(n).map(function () {
                return bumps(m, k);
            }))),
            layers = layers0.concat(layers1);
        console.log(layers0);

        var x = d3.scaleLinear()
            .domain([0, m - 1])
            .range([0, width]);

        var y = d3.scaleLinear()
            .domain([d3.min(layers, stackMin), d3.max(layers, stackMax)])
            .range([height, 0]);

//https://github.com/d3/d3-scale
        var z = d3.interpolateCool;

        var area = d3.area()
            .x(function (d, i) {
                return x(i);
            })
            .y0(function (d) {
                return y(d[0]);
            })
            .y1(function (d) {
                return y(d[1]);
            });

        svg.selectAll("path")
            .data(layers0)
            .enter().append("path")
            .attr("d", area)
            .attr("fill", function () {
                return z(Math.random());
            });
    }

    function stackMax(layer) {
        return d3.max(layer, function (d) {
            return d[1];
        });
    }

    function stackMin(layer) {
        return d3.min(layer, function (d) {
            return d[0];
        });
    }

    function transition() {
        var t;
        d3.selectAll("path")
            .data((t = layers1, layers1 = layers0, layers0 = t))
            .transition()
            .duration(2500)
            .attr("d", area);
    }

// Inspired by Lee Byron’s test data generator.
    function bumps(n, m) {
        var a = [], i;
        for (i = 0; i < n; ++i) a[i] = 0;
        for (i = 0; i < m; ++i) bump(a, n);
        return a;
    }

    function bump(a, n) {
        var x = 1 / (0.1 + Math.random()),
            y = 2 * Math.random() - 0.5,
            z = 10 / (0.1 + Math.random());
        for (var i = 0; i < n; i++) {
            var w = (i / n - y) * z;
            a[i] += x * Math.exp(-w * w);
        }
    }

}
function cacl(arr, callback) {
  var ret;
  for (var index=0; index<arr.length;index++) {
    ret = callback(arr[index], ret);
  }
  return ret;
}

Array.prototype.max = function () {
  return cacl(this, function (item, max) {
    if (!(max > item)) {
      return item;
    }
    else {
      return max;
    }
  });
};
Array.prototype.min = function () {
  return cacl(this, function (item, min) {
    if (!(min < item)) {
      return item;
    }
    else {
      return min;
    }
  });
};
Array.prototype.sum = function () {
  return cacl(this, function (item, sum) {
    if (typeof (sum) == 'undefined') {
      return item;
    }
    else {
      return sum += item;
    }
  });
};
Array.prototype.avg = function () {
  if (this.length == 0) {
    return 0;
  }
  return this.sum(this) / this.length;
};